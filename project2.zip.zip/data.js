const students = [
  { id: 1, name: "Rahul", course: "BCA", city: "Kolkata", fees: 20000 },
  { id: 2, name: "Priya", course: "MCA", city: "Delhi", fees: 30000 },
  { id: 3, name: "Amit", course: "BCA", city: "Mumbai", fees: 25000 }
];

module.exports = students;
