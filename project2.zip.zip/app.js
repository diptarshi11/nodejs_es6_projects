const express = require("express");
const students = require("./data");

const app = express();
app.use(express.json());

/* Welcome Message */
app.get("/", (req, res) => {
    res.send("Welcome to Student API");
});

/* Fetch All Students */
app.get("/students", (req, res) => {
    res.json(students);
});

/*Fetch Student By ID */
app.get("/students/:id", (req, res) => {
    const student = students.find(s => s.id == req.params.id);
    res.json(student || { message: "Student not found" });
});

/*Add New Student */
app.post("/students", (req, res) => {
    students.push(req.body);
    res.json({ message: "Student Added", students });
});

/* Delete Student */
app.delete("/students/:id", (req, res) => {
    const index = students.findIndex(s => s.id == req.params.id);

    if (index !== -1) {
        students.splice(index, 1);
        res.json({ message: "Student Deleted" });
    } else {
        res.json({ message: "Student not found" });
    }
});

/* Update Student */
app.put("/students/:id", (req, res) => {
    const student = students.find(s => s.id == req.params.id);

    if (student) {
        Object.assign(student, req.body);
        res.json({ message: "Updated", student });
    } else {
        res.json({ message: "Student not found" });
    }
});

/* Search By Name */
app.get("/search/name/:name", (req, res) => {
    const result = students.filter(
        s => s.name.toLowerCase().includes(req.params.name.toLowerCase())
    );
    res.json(result);
});

/* Search By Course */
app.get("/search/course/:course", (req, res) => {
    const result = students.filter(
        s => s.course.toLowerCase() === req.params.course.toLowerCase()
    );
    res.json(result);
});

/* Filter By City */
app.get("/search/city/:city", (req, res) => {
    const result = students.filter(
        s => s.city.toLowerCase() === req.params.city.toLowerCase()
    );
    res.json(result);
});

/*  Count Students */
app.get("/count", (req, res) => {
    res.json({ totalStudents: students.length });
});

/*  Fees Greater Than */
app.get("/fees/greater/:amount", (req, res) => {
    const amount = Number(req.params.amount);
    res.json(students.filter(s => s.fees > amount));
});

/* Fees Less Than */
app.get("/fees/less/:amount", (req, res) => {
    const amount = Number(req.params.amount);
    res.json(students.filter(s => s.fees < amount));
});

/*  Sort By Name */
app.get("/sort/name", (req, res) => {
    const result = [...students].sort((a, b) =>
        a.name.localeCompare(b.name)
    );
    res.json(result);
});

/*  Sort Fees Low To High */
app.get("/sort/fees/asc", (req, res) => {
    const result = [...students].sort((a, b) => a.fees - b.fees);
    res.json(result);
});

/*  Sort Fees High To Low */
app.get("/sort/fees/desc", (req, res) => {
    const result = [...students].sort((a, b) => b.fees - a.fees);
    res.json(result);
});

/* Check Student Exists */
app.get("/exists/:id", (req, res) => {
    const exists = students.some(s => s.id == req.params.id);
    res.json({ exists });
});

/* Total Fees Collected */
app.get("/fees/total", (req, res) => {
    const total = students.reduce((sum, s) => sum + s.fees, 0);
    res.json({ totalFees: total });
});

/*  Course Wise Students */
app.get("/course-wise", (req, res) => {
    const result = {};

    students.forEach(student => {
        if (!result[student.course]) {
            result[student.course] = [];
        }
        result[student.course].push(student);
    });

    res.json(result);
});

/* Add Multiple Students */
app.post("/students/many", (req, res) => {
    students.push(...req.body);
    res.json({ message: "Students Added" });
});

/* Dashboard Report */
app.get("/dashboard", (req, res) => {
    const totalStudents = students.length;
    const totalFees = students.reduce((sum, s) => sum + s.fees, 0);

    res.json({
        totalStudents,
        totalFees,
        students
    });
});

app.listen(3000, () => {
    console.log("Server running on port 3000");
});